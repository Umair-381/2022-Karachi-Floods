
# Dataset Links

## Sentinel-1 SAR Data
- **Source**: [Sentinel-1 SAR](https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S1_GRD)
- **Description**: Used for detecting flood extents based on pre- and post-event imagery.

## JRC Global Surface Water
- **Source**: [JRC Global Surface Water](https://developers.google.com/earth-engine/datasets/catalog/JRC_GSW1_4_GlobalSurfaceWater)
- **Description**: Used to mask out permanent water bodies from the flood extent layer.

## WWF HydroSHEDS DEM
- **Source**: [HydroSHEDS DEM](https://developers.google.com/earth-engine/datasets/catalog/WWF_HydroSHEDS_03VFDEM)
- **Description**: Utilized for masking out high-slope areas to refine flood detection.

## Global Human Settlement Population Density
- **Source**: [GHSL Population Density](https://developers.google.com/earth-engine/datasets/catalog/JRC_GHSL_P2016_POP_GPW_GLOBE_V1_2015)
- **Description**: Used for estimating the number of people exposed to flooding.

## MODIS Land Cover Type
- **Source**: [MODIS Land Cover](https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_Landcover_100m_Proba-V-C3_Global)
- **Description**: Used to assess affected cropland and urban areas during the flood event.
