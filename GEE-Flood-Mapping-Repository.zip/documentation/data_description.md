
# Data Description

## Sentinel-1 SAR Data
Sentinel-1 data is used to detect flood extents by comparing pre- and post-event imagery. The data is filtered by polarization (VH), pass direction (descending), and the relevant date ranges specified in the script.

## JRC Global Surface Water
This dataset helps to refine the flood extent by masking out areas of permanent water (defined as water present more than 10 months of the year).

## WWF HydroSHEDS DEM
The DEM is used to mask out steep slopes from the flood detection to minimize false positives due to terrain effects.

## Global Human Settlement Population Density
Population data is used to estimate the number of people exposed to flooding within the defined area of interest.

## MODIS Land Cover Type
Land cover data helps to assess affected cropland and urban areas, focusing on agricultural land and urban extents impacted by the flood.

## Data Processing
All datasets are preprocessed and clipped to the study area (AOI) defined in the code. Specific filters and parameters are applied as detailed within the GEE script (`flood_mapping.js`).
